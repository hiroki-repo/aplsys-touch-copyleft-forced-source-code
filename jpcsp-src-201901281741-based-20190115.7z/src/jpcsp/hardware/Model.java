/*
This file is part of jpcsp.

Jpcsp is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Jpcsp is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Jpcsp.  If not, see <http://www.gnu.org/licenses/>.
 */
package jpcsp.hardware;

public class Model {
	public static final int MODEL_PSP_FAT = 0;
	public static final int MODEL_PSP_SLIM = 1;
    public static final int MODEL_PSP_BRITE = 2;
    public static final int MODEL_PSP_BRITE2 = 3;
    public static final int MODEL_PSP_GO = 4;
	private static int model = MODEL_PSP_FAT;
	private static final String[] modelNames = new String[] {
		"MODEL_PSP_FAT",
		"MODEL_PSP_SLIM",
		"MODEL_PSP_BRITE",
		"MODEL_PSP_BRITE2",
		"MODEL_PSP_GO"
	};

	public static int getModel() {
		return model;
	}

	public static void setModel(int model) {
		Model.model = model;
	}

	public static String getModelName(int model) {
		if (model >= 0 && model < modelNames.length) {
			return modelNames[model];
		}

		return String.format("Unknown Model %d", model);
	}
}
