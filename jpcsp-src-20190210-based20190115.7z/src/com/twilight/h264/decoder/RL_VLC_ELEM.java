package com.twilight.h264.decoder;

public class RL_VLC_ELEM {
    short level; //int16_t level;
    int len; //int8_t len;
    int run; //uint8_t run;
}
